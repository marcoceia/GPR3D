%Grid Setup
disp('-------------------------------------------');
%grat=1;%Grid Ratio
%disp(['Grid Ratio = 1/',num2str(grat)]);
xmax=max(xin);xmin=min(xin);
%xstp=stepin/grat;
ymax=max(xcross);ymin=min(xcross);
%ystp=stepcross/grat;
zmax=max(tin);zmin=min(tin);
zstp1=dt*zstp;
disp(['Grid Cell Size X = ',num2str(xstp)]);
disp(['Grid Cell Size Y = ',num2str(ystp)]);
disp(['Grid Cell Size Z x dt = ',num2str(zstp1)]);
disp([' dt = ',num2str(dt)]);
disp('-------------------------------------------');
