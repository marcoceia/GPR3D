function [fv]=famprange(xi,yi,zi,vi,minamp,maxamp,intx,inty,intz);
%Amplitude Selection
%This script set a 3D matrix (cuv) in which values of the inerpolated
%matrix (vi) outside of the specified range are set to NaN. This way slices
%will show only the data which values are within the specified range.
%Author: Marco Ceia (marco@lenep.uenf.br)
%Getting max & min from vi
maxvi=max(max(max(vi)));
minvi=min(min(min(vi)));
disp(strcat('Max Val of 3D Interp Data :',num2str(maxvi)));
disp(strcat('Min Val of 3D Interp Data :',num2str(minvi)));
disp(strcat('Max Val Selected :',num2str(maxamp)));
disp(strcat('Min Val Selected :',num2str(minamp)));

[vidim1,vidim2,vidim3]=size(vi);

for ivi1=1:vidim1
    for ivi2=1:vidim2
        for ivi3=1:vidim3
            if(vi(ivi1,ivi2,3)>=minamp & vi(ivi1,ivi2,ivi3)<=maxamp)
                avi(ivi1,ivi2,ivi3)=vi(ivi1,ivi2,ivi3);
            else
                avi(ivi1,ivi2,ivi3)=NaN;
            end
        end
    end
    
end
slice(xi,yi,zi,avi,intx,inty,intz);
shading flat              
xlabel('X');
ylabel('Y');
zlabel('Z');
colormap(jet);
colorbar;
box on;
axis vis3d tight 