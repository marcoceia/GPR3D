%Ploting a slice of the data
figure
whos
slice(xi,yi,zi,vit,intx,inty,intz);
shading flat  
colormap(jet);
colorbar;
xlabel('X');
ylabel('Y');
zlabel('Z');            
axis vis3d ;


%hold on;