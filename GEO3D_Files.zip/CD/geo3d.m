%Program Geo3Db
%Author: Marco Ceia (marco@lenep.uenf.br) - UENF/LENEP
%v.2 - NOV/2007
%This program reads a set of 2D lines, in ASCII format, makes a 3D interpolation,
%store the data in a volume matrix and display plan slices.
%It works only with Sensors & Software datatype.
%Sintax: geo3d (When the program ask for input options file, enter the *.opt filename and path
%Ex. exascii.opt
%
clear all
clc
disp('############################################');
disp('#                GeO 3D Slices             #');
disp('#                 ASCII Input              #');
disp('#              Author: Marco Ceia          #');
disp('#                 UENF/LENEP               #');
disp('############################################');
%
filein1=input('Input filename : ','s');%ASCII file with input options
%Input Parameters
a=textread(filein1,'%s');
filein2=char(a(1));%GPR (*.dat) filename
ntrace=str2num(char(a(2)));%Number of traces
stepin=str2num(char(a(3))); %(Step size (between stations) - Inline)
stepcross=str2num(char(a(4))); %(Step size (between lines) - Crossline)
nfiles=str2num(char(a(5)));%Number of data files
%
if nfiles>1
    %Loading data filenames
    a=textread(filein2,'%s');
    for i=1:nfiles
        gprfile(i,:)=char(a(i));
    end
    temp1=load(gprfile(1,:));
    data=temp1(:,:);
    [ldata,cdata]=size(data);
    clear data;
    clear a;
    dt=1;%Delta time (GPR). Step size in z.
    %Crossline Coordinates
    %xcross = crossline x-coord
    for i=1:nfiles;xcross(i)=(i-1)*stepcross;end;    
    %
    %Loading data
    for l=1:nfiles
        disp(['Reading File #',num2str(l),' :',gprfile(l,:)]);
        temp1=load(gprfile(l,:));
        xin=1:cdata;tin=1:ldata;data=[temp1(:,:)];
        for j=1:ldata
            for i=1:cdata     
                data2(l,i,j)=data(j,i)';
                x(l,i,j)=xin(i);
                y(l,i,j)=xcross(l);
                z(l,i,j)=tin(j);
            end
        end
        clear data;
    end        

%Grid Setup
disp('-------------------------------------------');
grat=1;%Grid Ratio
disp(['Grid Ratio = 1/',num2str(grat)]);
xmax=max(xin);xmin=min(xin);xstp=1;%xstp=stepin/grat;
ymax=max(xcross);ymin=min(xcross);ystp=1;%ystp=stepcross/grat;
zmax=max(tin);zmin=min(tin);zstp=dt%ystp set to be equal to dt
disp(['Grid Cell Size X = ',num2str(xstp)]);
disp(['Grid Cell Size Y = ',num2str(ystp)]);
disp(['Grid Cell Size Z = ',num2str(zstp)]);
disp('-------------------------------------------');

%Memory Cleanup
clear filein1;
clear gprfile;
clear ldata;
clear cdata;
clear i;
clear j;
clear l;

%Building Mesh
disp('Building Mesh');
[xi,yi,zi]=meshgrid(xmin:xstp:xmax,ymin:ystp:ymax,zmin:zstp:zmax);

%Memory Cleanup
clear filein2;
clear zmax;
clear zmin;
clear zstp;
clear stepin;
clear stepcross;
clear xstp;
clear ystp;
clear xmax;
clear xmin;


%Making interpolated volume (vi)
disp('3D Interpolation');
vi=interp3(x,y,z,data2,xi,yi,zi);

%Memory Cleanup
clear x;
clear y;
clear z;
clear data2;
%Consolidate workspace memory
cwd = pwd;
cd(tempdir);
pack 
cd(cwd)
%

else
    disp('Not enough files available');
end
