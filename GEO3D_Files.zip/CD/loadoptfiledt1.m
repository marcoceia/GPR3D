%Input Parameters
a=textread(filein1,'%s');
filein2=char(a(1));%GPR (*.dt1) filename
ntrace=str2num(char(a(2)));%Number of traces
stepin=str2num(char(a(3))); %(Step size (offset) - Inline)
stepcross=str2num(char(a(4))); %(Step size (offset) - Crossline)
nfiles=str2num(char(a(5)));%Number of GPR files
%
if nfiles>1
    %Loading GPR filenames
    a=textread(filein2,'%s');
    for i=1:nfiles
        gprfile(i,:)=char(a(i));
    end
    %Loading first GPR file for test
    %xin = inline x-coord
    %tin = inline time
    [xin,tin,data,dt]=fscandt1(gprfile(1,:),ntrace,stepin);
    [ldata,cdata]=size(data);
    clear data;
    clear a;
    %
    %Crossline Coordinates
    %xcross = crossline x-coord
    for i=1:nfiles;xcross(i)=(i-1)*stepcross;end;    
    %
    %Loading data
    for l=1:nfiles
        disp(['Reading File #',num2str(l),' :',gprfile(l,:)]);
        [xin,tin,data,dt]=fscandt1(gprfile(l,:),ntrace,stepin);
        for j=1:ldata
            for i=1:cdata     
                data2(l,i,j)=data(j,i);
                x(l,i,j)=xin(i);
                y(l,i,j)=xcross(l);
                z(l,i,j)=tin(j);
            end
        end
        clear data;
    end        
end
%disp(filein1)
disp(strcat('OPT File Loaded : ',filein1))