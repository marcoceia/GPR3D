function [x,t,data2,dt]=fscandt1(name,ntrace,step);
%Program fscandt1
%Marco Ceia (marco@lenep.uenf.br)
%UENF/LENEP
%--------------------------------------------------
%Read pulseekko GPR data.
%function [x,t,data2,dt]=fscandt1(name,ntrace,step)
%x = position t = time
%data2 = amplitude values
%dt = number of samples / timewindow
%name = Filename ntrace = number of traces
%step = position increment
%Input File
fid=fopen(name,'r');

%File Reading

for i=1:ntrace
   i;
   header=fread(fid,32,'single');
   nptptr=header(3); %Number of points/trace
   data=fread(fid,nptptr,'int16');
   trace(:,i)=[header;data];
end
clear data;
st=fclose(fid);
data2=trace((33:nptptr),:);
[ldata2,cdata2]=size(data2);
dt=header(9)/(ldata2-1);
spc=step;%Spacing
for i=1:cdata2;x(i)=(i-1)*spc;end;    
for j=1:ldata2;t(j)=(j-1)*dt;end;