%Ploting a slice of the data
figure
box on;

slice(xi,yi,zi,vi,intx,inty,intz);
shading interp 
colormap(jet);
colorbar;
xlabel('X');
ylabel('Y');
zlabel('Z');            
axis vis3d ;


%hold on;