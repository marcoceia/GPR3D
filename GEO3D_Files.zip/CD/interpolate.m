%Making interpolated volume (vi)
disp('3D Interpolation');
vi=interp3(x,y,z,data2,xi,yi,zi);
