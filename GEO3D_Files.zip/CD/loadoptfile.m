%Input Parameters
a=textread(filein1,'%s');
filein2=char(a(1));%GPR (*.dt1 or *.dat) filename
ntrace=str2num(char(a(2)));%Number of traces
stepin=str2num(char(a(3))); %(Step size (offset) - Inline)
stepcross=str2num(char(a(4))); %(Step size (offset) - Crossline)
nfiles=str2num(char(a(5)));%Number of GPR files
%
if nfiles>1
    %Loading Data filenames
    a=textread(filein2,'%s');
    for i=1:nfiles
        a(i)
        gprfile(i,:)=char(a(i))
    end
    temp1=load(gprfile(1,:));
    data=temp1(:,:);
    [ldata,cdata]=size(data);
    clear data;
    clear a;
    dt=1;
    %Crossline Coordinates
    %xcross = crossline x-coord
    for i=1:nfiles;xcross(i)=(i-1)*stepcross;end;    
    %
    %Loading data
    for l=1:nfiles
        disp(['Reading File #',num2str(l),' :',gprfile(l,:)]);
        %[xin,tin,data,dt]=fscandt1(gprfile(l,:),ntrace,stepin);
     temp1=load(gprfile(l,:));
    %xin=[temp1(:,1)];tin=[temp1(:,2)];data=[temp1(:,3)];
   xin=(1:cdata)';tin=(1:ldata)';data=[temp1(:,:)];
        for j=1:ldata
            for i=1:cdata     
                data2(l,i,j)=data(j,i);
                x(l,i,j)=xin(i);
                y(l,i,j)=xcross(l);
                z(l,i,j)=tin(j);
            end
        end
        clear data;
    end        
end
%disp(filein1)
disp('OPT File Loaded')