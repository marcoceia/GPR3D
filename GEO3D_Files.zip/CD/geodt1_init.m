function varargout = geodt1_init(varargin)
% GEODT1_INIT M-file for geodt1_init.fig
%      GEODT1_INIT, by itself, creates a new GEODT1_INIT or raises the existing
%      singleton*.
%
%      H = GEODT1_INIT returns the handle to a new GEODT1_INIT or the handle to
%      the existing singleton*.
%
%      GEODT1_INIT('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in GEODT1_INIT.M with the given input arguments.
%
%      GEODT1_INIT('Property','Value',...) creates a new GEODT1_INIT or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before geodt1_init_OpeningFunction gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to geodt1_init_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Copyright 2002-2003 The MathWorks, Inc.

% Edit the above text to modify the response to help geodt1_init

% Last Modified by GUIDE v2.5 10-Dec-2007 16:20:51

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @geodt1_init_OpeningFcn, ...
                   'gui_OutputFcn',  @geodt1_init_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before geodt1_init is made visible.
function geodt1_init_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to geodt1_init (see VARARGIN)

% Choose default command line output for geodt1_init
handles.output = hObject;

% Update handles structure
guidata(hObject, handles);

% UIWAIT makes geodt1_init wait for user response (see UIRESUME)
% uiwait(handles.figure1);


% --- Outputs from this function are returned to the command line.
function varargout = geodt1_init_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;






% --- Executes on selection change in popupmenu2.
function popupmenu2_Callback(hObject, eventdata, handles)
% hObject    handle to popupmenu2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = get(hObject,'String') returns popupmenu2 contents as cell array
%        contents{get(hObject,'Value')} returns selected item from popupmenu2


% --- Executes during object creation, after setting all properties.
function popupmenu2_CreateFcn(hObject, eventdata, handles)
% hObject    handle to popupmenu2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc
    set(hObject,'BackgroundColor','white');
else
    set(hObject,'BackgroundColor',get(0,'defaultUicontrolBackgroundColor'));
end

% --- If Enable == 'on', executes on mouse press in 5 pixel border.
% --- Otherwise, executes on mouse press in 5 pixel border or over text1.
function text1_ButtonDownFcn(hObject, eventdata, handles)
% hObject    handle to text1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% --- Executes during object creation, after setting all properties.
function popupmenu4_CreateFcn(hObject, eventdata, handles)
% hObject    handle to popupmenu4 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc
    set(hObject,'BackgroundColor','white');
else
    set(hObject,'BackgroundColor',get(0,'defaultUicontrolBackgroundColor'));
end


% --- Executes on selection change in Configuration.
function Configuration_Callback(hObject, eventdata, handles)
% hObject    handle to Configuration (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = get(hObject,'String') returns Configuration contents as cell array
%        contents{get(hObject,'Value')} returns selected item from Configuration

% --- Executes on selection change in popupmenu5.
function popupmenu5_Callback(hObject, eventdata, handles)
% hObject    handle to popupmenu5 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = get(hObject,'String') returns popupmenu5 contents as cell array
%        contents{get(hObject,'Value')} returns selected item from popupmenu5


% --- Executes during object creation, after setting all properties.
function popupmenu5_CreateFcn(hObject, eventdata, handles)
% hObject    handle to popupmenu5 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc
    set(hObject,'BackgroundColor','white');
else
    set(hObject,'BackgroundColor',get(0,'defaultUicontrolBackgroundColor'));
end



function filein1_Callback(hObject, eventdata, handles)
% hObject    handle to filein1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of filein1 as text
%        str2double(get(hObject,'String')) returns contents of filein1 as a double


% --- Executes during object creation, after setting all properties.
function filein1_CreateFcn(hObject, eventdata, handles)
% hObject    handle to filein1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc
    set(hObject,'BackgroundColor','white');
else
    set(hObject,'BackgroundColor',get(0,'defaultUicontrolBackgroundColor'));
end



function edit1_Callback(hObject, eventdata, handles)
% hObject    handle to edit1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit1 as text
%        str2double(get(hObject,'String')) returns contents of edit1 as a double

%filein1=get(edit1,'string')
handles.edit1=get(hObject,'String')
%handles.edit1=filein1;
% Update handles structure
guidata(hObject, handles);


% --- Executes on button press in pushbutton2.
function pushbutton2_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of pushbutton2

%filein1=get(handles.edit1,'String')
[filein1, pathname, filterindex] = uigetfile('*.opt', 'Input Options (*.opt) File');
%filein1=handles.edit1;
handles.filein1=filein1;
loadoptfiledt1
handles.xin=xin;
handles.xcross=xcross;
handles.tin=tin;
handles.dt=dt;
handles.x=x;
handles.y=y;
handles.z=z;
handles.data2=data2;
% Update handles structure
guidata(hObject, handles);


% --- Executes on button press in togglebutton2.
function togglebutton2_Callback(hObject, eventdata, handles)
% hObject    handle to togglebutton2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of togglebutton2
filein1=handles.filein1;
edit(filein1)
guidata(hObject, handles);





function edity_Callback(hObject, eventdata, handles)
% hObject    handle to edity (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edity as text
%        str2double(get(hObject,'String')) returns contents of edity as a double
handles.edity=(get(hObject,'String'));
guidata(hObject, handles);


% --- Executes during object creation, after setting all properties.
function edity_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edity (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc
    set(hObject,'BackgroundColor','white');
else
    set(hObject,'BackgroundColor',get(0,'defaultUicontrolBackgroundColor'));
end



function editz_Callback(hObject, eventdata, handles)
% hObject    handle to editz (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of editz as text
%        str2double(get(hObject,'String')) returns contents of editz as a double
handles.editz=get(hObject,'String');
guidata(hObject, handles);


% --- Executes during object creation, after setting all properties.
function editz_CreateFcn(hObject, eventdata, handles)
% hObject    handle to editz (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc
    set(hObject,'BackgroundColor','white');
else
    set(hObject,'BackgroundColor',get(0,'defaultUicontrolBackgroundColor'));
end



function editx_Callback(hObject, eventdata, handles)
% hObject    handle to editx (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of editx as text
%        str2double(get(hObject,'String')) returns contents of editx as a double

handles.editx=get(hObject,'String');
guidata(hObject, handles);

% --- Executes during object creation, after setting all properties.
function editx_CreateFcn(hObject, eventdata, handles)
% hObject    handle to editx (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc
    set(hObject,'BackgroundColor','white');
else
    set(hObject,'BackgroundColor',get(0,'defaultUicontrolBackgroundColor'));
end

handles.editx=get(hObject,'String');
guidata(hObject, handles);


% --- Executes on button press in pushbutton3.
function pushbutton3_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton3 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
%Grid Steps apply button
xstp=str2num(handles.editx);
ystp=str2num(handles.edity);
zstp=str2num(handles.editz);
    xin=handles.xin;
    xcross=handles.xcross;
    tin=handles.tin;
    dt=handles.dt;  
gridsetup
handles.xmin=xmin;
handles.xmax=xmax;
handles.ymin=ymin;
handles.ymax=ymax;
handles.zmin=zmin;
handles.zmax=zmax;
guidata(hObject, handles);


% --- Executes during object creation, after setting all properties.
function uipanel2_CreateFcn(hObject, eventdata, handles)
% hObject    handle to uipanel2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called



function edit7_Callback(hObject, eventdata, handles)
% hObject    handle to edit7 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit7 as text
%        str2double(get(hObject,'String')) returns contents of edit7 as a double
%Xint
handles.edit7=get(hObject,'String');
guidata(hObject, handles);

% --- Executes during object creation, after setting all properties.
function edit7_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit7 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc
    set(hObject,'BackgroundColor','white');
else
    set(hObject,'BackgroundColor',get(0,'defaultUicontrolBackgroundColor'));
end



function edit8_Callback(hObject, eventdata, handles)
% hObject    handle to edit8 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit8 as text
%        str2double(get(hObject,'String')) returns contents of edit8 as a double
%Yint
handles.edit8=get(hObject,'String');
guidata(hObject, handles);

% --- Executes during object creation, after setting all properties.
function edit8_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit8 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc
    set(hObject,'BackgroundColor','white');
else
    set(hObject,'BackgroundColor',get(0,'defaultUicontrolBackgroundColor'));
end



function edit9_Callback(hObject, eventdata, handles)
% hObject    handle to edit9 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit9 as text
%        str2double(get(hObject,'String')) returns contents of edit9 as a double
%Zint 
handles.edit9=get(hObject,'String');
guidata(hObject, handles);

% --- Executes during object creation, after setting all properties.
function edit9_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit9 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc
    set(hObject,'BackgroundColor','white');
else
    set(hObject,'BackgroundColor',get(0,'defaultUicontrolBackgroundColor'));
end




% --- Executes on button press in pushbutton4.
function pushbutton4_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton4 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
%Show button
disp('Preparing to plot 3D slices')
intx=str2num(handles.edit7);
inty=str2num(handles.edit8);
intz=str2num(handles.edit9);
xi=handles.xi;
yi=handles.yi;
zi=handles.zi;
vi=handles.vi;
%Consolidate workspace memory
cwd = pwd;
cd(tempdir);
pack 
cd(cwd)
%
disp('Ploting a slice');
showslice
handles.intx=intx;
handles.inty=inty;
handles.intz=intz;
guidata(hObject, handles);




% --- Executes on key press over pushbutton4 with no controls selected.
function pushbutton4_KeyPressFcn(hObject, eventdata, handles)
% hObject    handle to pushbutton4 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)




% --- Executes on button press in pushbutton5.
function pushbutton5_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton5 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
disp('Interpolate button actived')
x=handles.x;
y=handles.y;
z=handles.z;
dt=handles.dt;
xmin=handles.xmin;
xmax=handles.xmax;
ymin=handles.ymin;
ymax=handles.ymax;
zmin=handles.zmin;
zmax=handles.zmax;
data2=handles.data2;
xstp=str2num(handles.editx);
ystp=str2num(handles.edity);
zstp=str2num(handles.editz);
%Building 3D meshgrid
buildmesh
handles.xi=xi;
handles.yi=yi;
handles.zi=zi;
%3D Interpolation
interpolate
handles.vi=vi;
guidata(hObject, handles);



% --- Executes on button press in pushbutton7.
function pushbutton7_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton7 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
%Quit button
clear all
close



% --- Executes on button press in pushbutton8.
function pushbutton8_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton8 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
%Back button
clear all
close
geo3dinit



% --- Executes on button press in savebut.
function savebut_Callback(hObject, eventdata, handles)
% hObject    handle to savebut (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
%Save to MAT button
xi=handles.xi;
yi=handles.yi;
zi=handles.zi;
vi=handles.vi;
[file2save,pathname]=uiputfile('*.mat','Save Interpolated data as a MAT file')
save(file2save,'xi','yi','zi','vi');
disp(strcat('3D Interpolated Data was stored in :',file2save))

guidata(hObject, handles);
% --- Executes on button press in loadmatbut.
function loadmatbut_Callback(hObject, eventdata, handles)
% hObject    handle to loadmatbut (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
%Load MAT button
[matfilein1, pathname, filterindex] = uigetfile('*.mat', 'Input MAT File contained interpolated data');
load(matfilein1,'xi','yi','zi','vi');
handles.xi=xi;
handles.yi=yi;
handles.zi=zi;
handles.vi=vi;
maxxi=max(max(max(xi,[],1)));
maxyi=max(max(max(yi,[],1)));
maxzi=max(max(max(zi,[],1)));
minxi=min(min(min(xi,[],1)));
minyi=min(min(min(yi,[],1)));
minzi=min(min(min(zi,[],1)));

disp(strcat('X :',num2str(minxi),'-',num2str(maxxi)))
disp(strcat('Y :',num2str(minyi),'-',num2str(maxyi)))
disp(strcat('Z :',num2str(minzi),'-',num2str(maxzi)))
guidata(hObject, handles);


% --- Executes on button press in help.
function help_Callback(hObject, eventdata, handles)
% hObject    handle to help (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
helpgeo3d





function minamp_Callback(hObject, eventdata, handles)
% hObject    handle to minamp (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of minamp as text
%        str2double(get(hObject,'String')) returns contents of minamp as a double
minamp=get(hObject,'String');
handles.minamp=str2num(minamp);
guidata(hObject, handles);


% --- Executes during object creation, after setting all properties.
function minamp_CreateFcn(hObject, eventdata, handles)
% hObject    handle to minamp (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc
    set(hObject,'BackgroundColor','white');
else
    set(hObject,'BackgroundColor',get(0,'defaultUicontrolBackgroundColor'));
end



function maxamp_Callback(hObject, eventdata, handles)
% hObject    handle to maxamp (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of maxamp as text
%        str2double(get(hObject,'String')) returns contents of maxamp as a double
maxamp=get(hObject,'String');
handles.maxamp=str2num(maxamp);
guidata(hObject, handles);


% --- Executes during object creation, after setting all properties.
function maxamp_CreateFcn(hObject, eventdata, handles)
% hObject    handle to maxamp (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc
    set(hObject,'BackgroundColor','white');
else
    set(hObject,'BackgroundColor',get(0,'defaultUicontrolBackgroundColor'));
end


% --- Executes on button press in amprangeb.
function amprangeb_Callback(hObject, eventdata, handles)
% hObject    handle to amprangeb (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
%Amplitude Selection
%This script set a 3D matrix (cuv) in which values of the inerpolated
%matrix (vi) outside of the specified range are set to NaN. This way slices
%will show only the data which values are within the specified range.
%Author: Marco Ceia (marco@lenep.uenf.br)
%Getting max & min from vi
xi=handles.xi;
yi=handles.yi;
zi=handles.zi;
vi=handles.vi;
minamp=handles.minamp;
maxamp=handles.maxamp;
intx=handles.intx;
inty=handles.inty;
intz=handles.intz;

maxvi=max(max(max(vi)));
minvi=min(min(min(vi)));
disp(strcat('Max Val of 3D Interp Data :',num2str(maxvi)));
disp(strcat('Min Val of 3D Interp Data :',num2str(minvi)));
disp(strcat('Max Val Selected :',num2str(maxamp)));
disp(strcat('Min Val Selected :',num2str(minamp)));

[vidim1,vidim2,vidim3]=size(vi);%vi dimensions
%Interval selection. Applying NaN to values outside the interval selected
for ivi1=1:vidim1
    for ivi2=1:vidim2
        for ivi3=1:vidim3
            if(vi(ivi1,ivi2,ivi3)>=minamp & vi(ivi1,ivi2,ivi3)<=maxamp)
                avi(ivi1,ivi2,ivi3)=vi(ivi1,ivi2,ivi3);
            else
                avi(ivi1,ivi2,ivi3)=NaN;
            end
        end
    end   
end
avimax=max(max(max(avi)));
avimin=min(min(min(avi)));
disp(strcat('Max Val Founded :',num2str(avimax)));
disp(strcat('Min Val Founded :',num2str(avimin)));
if (isnan(avimax) | isnan(avimin))==1
    disp('Choose other limits to interval');
end
disp('Ploting a slice');
figure
slice(xi,yi,zi,avi,intx,inty,intz);
shading interp              
xlabel('X');
ylabel('Y');
zlabel('Z');
colormap(jet);
colorbar;
box on;
axis vis3d tight 



