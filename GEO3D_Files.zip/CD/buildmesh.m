%Building Mesh
disp('Building Mesh');
disp(strcat('xmin :',num2str(xmin),'xstp :',num2str(xstp),'xmax :',num2str(xmax)));
disp(strcat('ymin :',num2str(ymin),'ystp :',num2str(ystp),'ymax :',num2str(ymax)));
disp(strcat('zmin :',num2str(zmin),'zstp :',num2str(zstp),'zmax :',num2str(zmax)));
[xi,yi,zi]=meshgrid(xmin:xstp:xmax,ymin:ystp:ymax,zmin:zstp:zmax);
disp('Mesh Created');
